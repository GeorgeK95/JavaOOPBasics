package app.utilities;

public class Constants {
    public static final String STRING_CONST = "END";
    public static final int INT_CONST = 0;

    public static final String INPUT_TERMINATING_COMMAND = "BEER IS COMING";


    private Constants() {
//        Collections.unmodifiableList(new ArrayList<>());
    }
}
