package app.entities;

import app.entities.cell.BloodCell;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Created by George-Lenovo on 6/29/2017.
 */
public class Cluster {
    private String id;// – a string that describes the name of the cluster, unique property;
    private int rows;//– a positive integer that describes how many rows the cluster has;
    private int cols;//– a positive integer that describes how many columns the cluster has;
    private List<Cell> cells;// – a collection of objects of type Cell;

//    private Cell[][] cellsA;

    public Cluster(String id, int rows, int cols/*, List<Cell> cells*/) {
        this.id = id;
        this.rows = rows;
        this.cols = cols;
//        cellsA = new Cell[this.rows][this.cols];
        this.cells = new ArrayList<>();
//        this.cells = cells;
    }

    void activateCluster() {
        Cell closest = this.getClosestCell(0, 0);
        if (closest != null) {
            //move cell
//            List<String> path = this.makePathForCell(closest);

            while (true) {
                if (!this.checkForOtherCells(closest.getPositionRow(), closest.getPositionCol())) {
                    break;
                }
                moveCell(closest);
            }

        }
    }

    private void moveCell(Cell start) {
        int r = start.getPositionRow();
        int c = start.getPositionCol();

        if (c + 1 > this.rows) {
            r += 1;
            c = 0;
        } else {
            c += 1;
        }
       /* start.setPositionRow(r);
        start.setPositionCol(c);*/

        Cell next = this.getCellByCoordinates(r, c);
        if (next != null) {
            Cell winner = fight(start, next);
            winner.setPositionRow(r);
            winner.setPositionCol(c);
        } else {
            start.setPositionRow(r);
            start.setPositionCol(c);
        }
    }

    private Cell getCellByCoordinates(int r, int c) {
        for (Cell cell : cells) {
            if (cell.getPositionRow() == r && cell.getPositionCol() == c) {
                return cell;
            }
        }
        return null;
    }

    private Cell fight(Cell start, Cell next) {
        if (start instanceof BloodCell)/* && (next instanceof Microbe || next instanceof BloodCell))*/ {
            start.setHealth(start.getHealth() + next.getHealth());
            this.cells.remove(next); //check
        } else /*if (start instanceof Microbe && (next instanceof Microbe || next instanceof BloodCell))*/ {
            while (true) {
                //1 -> 2
                next.setHealth(next.getHealth() - start.calculateEnergy());
                if (next.getHealth() <= 0) {
                    //start wins, next -> KO
                    this.cells.remove(next);//check
                    return start;
                }
                //2 -> 1
                start.setHealth(start.getHealth() - next.calculateEnergy());
                if (start.getHealth() <= 0) {
                    //next wins, start -> KO
                    this.cells.remove(start);//check
                    return next;
                }

            }
        }
        return start;
    }

    private boolean checkForOtherCells(int positionRow, int positionCol) {
        Cell closestCell = this.getClosestCell(positionRow, positionCol + 1);
        return closestCell != null;
    }

   /* private void moveCell(Cell closest) {
        this.cellsA[closest.getPositionRow()][closest.getPositionCol()] = null;
        Cell next;

        try {
            next = this.cellsA[closest.getPositionRow()][closest.getPositionCol() + 1];
        } catch (ArrayIndexOutOfBoundsException col) {
            next = this.cellsA[closest.getPositionRow() + 1][closest.getPositionCol()];
        }

        if (next != null) {
//            fight(closest, next);
        } else {
            try {
                this.cellsA[closest.getPositionRow()][closest.getPositionCol()] =
                        this.cellsA[closest.getPositionRow()][closest.getPositionCol() + 1];
            } catch (ArrayIndexOutOfBoundsException col) {
                this.cellsA[closest.getPositionRow() + 1][closest.getPositionCol()] =
                        this.cellsA[closest.getPositionRow()][closest.getPositionCol() + 1];
            }
            this.cellsA[next.getPositionRow()][next.getPositionCol()] = closest;
        }

    }

    private boolean checkForOtherCells(int positionRow, int positionCol) {
        for (int i = positionRow; i < cellsA.length; i++) {
            for (int j = positionCol; j < cellsA[i].length; j++) {
                try {
                    Cell cell = cellsA[i][j];
                    return true;
                } catch (ArrayIndexOutOfBoundsException ignored) {
                }

            }
        }
        return false;
    }

   /* private List<String> makePathForCell(Cell closest) {
        List<String> path = new ArrayList<>();
        int startRow = closest.getPositionRow();
        int startCol = closest.getPositionCol();

        for (int i = startRow + 1; i < this.rows; i++) {
            for (int j = startCol + 1; j < this.cols; j++) {
                String current = i + " " + j;
            }
        }

        return path;
    }*/

    private Cell getClosestCell(int rowParam, int colParam) {
        for (int currentRow = rowParam; currentRow <= this.rows; currentRow++) {
            for (int currentCol = colParam; currentCol <= this.cols; currentCol++) {
                for (Cell cell : this.cells) {
                    if (cell.getPositionRow() == currentRow && cell.getPositionCol() == currentCol) {
                        return cell;
                    }
                }
            }
            colParam = 0;
        }
        return null;


       /* for (int i = 0; i < cellsA.length; i++) {
            for (int j = 0; j < cellsA[i].length; j++) {
                try {
                    return cellsA[i][j];
                } catch (ArrayIndexOutOfBoundsException ignored) {
                }
            }
        }
        return null;*/
    }

   /* private Cell getRightmostCellInGivenCol(List<Cell> foundCells) {
        for (int i = 0; i < this.cols; i++) {
            for (Cell foundCell : foundCells) {
                if (foundCell.getPositionCol() == i) {
                    return foundCell;
                }
            }
        }
        return null;
    }*/

   /* private List<Cell> getCellsInGivenRow(int currentRow) {
        List<Cell> collected = new ArrayList<>();
        for (Cell cell : this.cells) {
            if (cell.getPositionRow() == currentRow) {
                collected.add(cell);
            }
        }
        return collected;
    }*/


    public void addCell(Cell cell) {
//        this.cellsA[cell.getPositionRow()][cell.getPositionCol()] = cell;
        this.cells.add(cell);
    }

    //GETTERS
    int getCellsSize() {
        return this.rows * this.cols;
//        return cells.size();
    }

    public List<Cell> getCells() {
        return cells;
    }

    public int getRows() {
        return rows;
    }

    public int getCols() {
        return cols;
    }

    public String getId() {
        return id;
    }

    //toString
    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append(String.format("----Cluster %s", this.id));
        builder.append(System.lineSeparator());
        /*for (Cell[] ints : this.cellsA) {
            for (Cell cell : ints) {
                builder.append(cell.toString());
                builder.append(System.lineSeparator());
            }
        }*/

        Comparator<? super Cell> comp = new Comparator<Cell>() {
            @Override
            public int compare(Cell o1, Cell o2) {
                return 0;
            }
        };
        List<Cell> ordered = this.cells.stream().sorted(comp).collect(Collectors.toList());
        for (Cell cell : this.cells) {
            builder.append(cell.toString());
            builder.append(System.lineSeparator());
        }

        return builder.toString().trim();
    }
}
