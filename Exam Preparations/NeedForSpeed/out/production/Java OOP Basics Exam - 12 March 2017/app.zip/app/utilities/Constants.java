package app.utilities;

public class Constants {
    public static final String INPUT_TERMINATING_COMMAND = "Cops Are Here";

    public static final int HOURSE_POWER_INCREASE_PERCENTAGE = 50;
    public static final int SUSPENSION_INCREASE_PERCENTAGE = 25;

    public static final String SHOW_CAR_TYPE = "Show";
    public static final String PERFORMANCE_CAR_TYPE = "Performance";

    public static final String DRIFT_RACE_TYPE = "Drift";
    public static final String DRAG_RACE_TYPE = "Drag";
    public static final String CASUAL_RACE_TYPE = "Casual";

    //percentages
    public static final int FIRST_PRICE_POOL_PERCENTAGE = 50;
    public static final int SECOND_PRICE_POOL_PERCENTAGE = 30;
    public static final int THIRD_PRICE_POOL_PERCENTAGE = 20;
    public static final int MAX_PERCENTAGE = 100;

    public static final String RACE_HAS_NO_PARTICIPANTS_MESSAGE = "Cannot start the race with zero participants.";
    public static final String EMPTY_STRING = "";


    private Constants() {
    }
}
