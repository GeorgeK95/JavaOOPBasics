package wildFarm;

/**
 * Created by George-Lenovo on 6/29/2017.
 */
class Meat extends Vegetable {

    Meat(int quantity) {
        super(quantity);
    }
}
