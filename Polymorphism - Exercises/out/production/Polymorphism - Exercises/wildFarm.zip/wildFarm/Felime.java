package wildFarm;

/**
 * Created by George-Lenovo on 6/29/2017.
 */
abstract class Felime extends Mammal {

    Felime(String animalName, String animalType, double animalWeight, String livingRegion) {
        super(animalName, animalType, animalWeight, livingRegion);
    }
}
