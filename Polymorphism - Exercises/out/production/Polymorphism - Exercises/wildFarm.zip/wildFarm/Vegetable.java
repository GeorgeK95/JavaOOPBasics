package wildFarm;

/**
 * Created by George-Lenovo on 6/29/2017.
 */
class Vegetable extends Food {

    Vegetable(int quantity) {
        super(quantity);
    }
}
